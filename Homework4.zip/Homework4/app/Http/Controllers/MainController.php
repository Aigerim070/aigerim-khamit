<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MainController extends Controller
{
    public function show(Request $request){
        	$firstname = $request -> input('firstname');
        	$lastname = $request -> input('lastname');
    		echo '<h1>Hi! My name is ' . $firstname . ' and surname is ' . $lastname . '!</h1>';
       }
}
