<!DOCTYPE html>
<html lang="en">
<head>
  <title>HW4</title>
  <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>

	<form action="log_action" method="post">
	  <input type="hidden" name="_token" value="{{csrf_token()}}">
	  First name:<br>
	  <input type="name" id="firstname" name="firstname"><br>
	  Last name:<br>
	  <input type="name" id="lastname" name="lastname"><br><br>
	  <button type="submit">Submit</button>
	</form> 

</body>
</html>
